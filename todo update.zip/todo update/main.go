package main

import (
	"html/template"
	"log"
	"net/http"
	"strconv"
)

var tmpl *template.Template

type List struct {
	Object string
	Finish bool
}

type PageInfo struct {
	Title string
	Todos []List
}

func list(w http.ResponseWriter, r *http.Request) {
	data := PageInfo{
		Title: "ToDo List",
		Todos: todos,
	}
	tmpl.Execute(w, data)
}

func create(w http.ResponseWriter, r *http.Request) {
	// Parse form data to get the new todo task
	r.ParseForm()
	todoObject := r.Form.Get("todo")

	// Append the new task to the existing list of todos
	todos = append(todos, List{Object: todoObject, Finish: false})

	// Redirect back to the homepage
	http.Redirect(w, r, "/", http.StatusSeeOther)
}

func update(w http.ResponseWriter, r *http.Request) {
	r.ParseForm()
	todoIndexStr := r.Form.Get("todo")
	todoIndex, err := strconv.Atoi(todoIndexStr)
	if err != nil || todoIndex < 0 || todoIndex >= len(todos) {
		http.Error(w, "Invalid task index", http.StatusBadRequest)
		return
	}

	// Mark the task at the specified index as done
	todos[todoIndex].Finish = true

	http.Redirect(w, r, "/", http.StatusSeeOther)
}

func remove(w http.ResponseWriter, r *http.Request) {
	r.ParseForm()
	todoIndexStr := r.Form.Get("todo")
	todoIndex, err := strconv.Atoi(todoIndexStr)
	if err != nil || todoIndex < 0 || todoIndex >= len(todos) {
		http.Error(w, "Invalid task index", http.StatusBadRequest)
		return
	}

	// Remove the task at the specified index from the todos slice
	todos = append(todos[:todoIndex], todos[todoIndex+1:]...)

	http.Redirect(w, r, "/", http.StatusSeeOther)
}

func rename(w http.ResponseWriter, r *http.Request) {
	r.ParseForm()
	todoIndexStr := r.Form.Get("todo")
	newName := r.Form.Get("newName")

	todoIndex, err := strconv.Atoi(todoIndexStr)
	if err != nil || todoIndex < 0 || todoIndex >= len(todos) {
		http.Error(w, "Invalid task index", http.StatusBadRequest)
		return
	}

	// Update the task name with the new name
	todos[todoIndex].Object = newName

	http.Redirect(w, r, "/", http.StatusSeeOther)
}

var todos = []List{}

func main() {
	mux := http.NewServeMux()
	tmpl = template.Must(template.ParseFiles("templates/mark.gohtml"))

	fs := http.FileServer(http.Dir("./static"))
	mux.Handle("/static/", http.StripPrefix("/static/", fs))
	mux.HandleFunc("/", list)
	mux.HandleFunc("/create", create)
	mux.HandleFunc("/update", update)
	mux.HandleFunc("/remove", remove)
	mux.HandleFunc("/rename", rename)

	/*go func() {
		for {
			removeCompleted()
			time.Sleep(time.Hour)
		}
	}() */

	log.Fatal(http.ListenAndServe(":8080", mux))
}
